# Karda — Ediciones físicas para cinéfilos

Proyecto final de frontend (HTML5, CSS3 y JavaScript ES6+, sin frameworks). Tienda web de DVD, Blu-ray y 4K UHD de cine.

- **Web desplegada:** _(pegar URL de GitHub Pages / Netlify)_
- **Figma (Proyecto 1):** _(pegar enlace)_
- **Memoria técnica:** `Memoria_Karda.pdf`
- **Tablero Kanban:** `KANBAN.md`

## Qué incluye
Catálogo dinámico con buscador y filtros, ficha de detalle, favoritos (localStorage), formularios con validación propia, modales y diseño responsive (Grid + Flexbox, breakpoints 600px y 1024px).

## Ejecutar en local
Abre la carpeta en VS Code y usa **Live Server** sobre `index.html`.

## Desplegar
GitHub Pages: *Settings → Pages → Source: GitHub Actions* (workflow incluido). Netlify: arrastrar la carpeta o conectar el repo (`netlify.toml` incluido).

## Autor
Darío Monrabal Vidal · Desarrollo de Aplicaciones Web
