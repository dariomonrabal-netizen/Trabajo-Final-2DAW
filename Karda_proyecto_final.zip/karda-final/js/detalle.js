// ============================================================
// detalle.js
// Rellena detalle.html con la película indicada en la URL
// (detalle.html?id=3) y gestiona los botones de la ficha.
// ============================================================

const parametrosURL = new URLSearchParams(window.location.search);
const idPelicula = Number(parametrosURL.get("id"));

// Si no hay id válido se queda la ficha estática del Hito 1
const peliculaActual = peliculas.find(function (p) { return p.id === idPelicula; }) || peliculas[3];

function textoDe(id, texto) {
  document.getElementById(id).textContent = texto;
}

// Título con la parte final en cursiva (como en el diseño original)
function ponerTitulo(titulo) {
  const h1 = document.getElementById("titulo-pelicula");
  const palabras = titulo.split(" ");
  if (palabras.length > 1) {
    const ultima = palabras.pop();
    h1.innerHTML = palabras.join(" ") + " <em>" + ultima + "</em>";
  } else {
    const mitad = Math.ceil(titulo.length / 2);
    h1.innerHTML = titulo.slice(0, mitad) + "<em>" + titulo.slice(mitad) + "</em>";
  }
}

if (document.getElementById("detalle-imagen")) {
  const imagen = document.getElementById("detalle-imagen");
  imagen.src = peliculaActual.imagen;
  imagen.alt = "Portada de " + peliculaActual.titulo;

  const etiqueta = document.getElementById("detalle-etiqueta");
  etiqueta.className = "etiqueta " + CLASE_FORMATO[peliculaActual.formato];
  etiqueta.textContent = NOMBRE_FORMATO[peliculaActual.formato];

  ponerTitulo(peliculaActual.titulo);
  document.title = peliculaActual.titulo + " | Karda";
  textoDe("detalle-precio", peliculaActual.precio.toFixed(2).replace(".", ",") + " €");
  textoDe("detalle-director", peliculaActual.director);
  textoDe("detalle-ano", peliculaActual.ano);
  textoDe("detalle-duracion", peliculaActual.duracion + " min");
  textoDe("detalle-formato", NOMBRE_FORMATO[peliculaActual.formato]);
  textoDe("detalle-estado", peliculaActual.estado);
  textoDe("detalle-sinopsis", peliculaActual.sinopsis);
}

// Botón "Añadir al carrito" -> modal de confirmación
const botonCarrito = document.getElementById("btn-carrito");
if (botonCarrito) {
  botonCarrito.addEventListener("click", function () {
    if (peliculaActual.stock === 0) {
      abrirModal("Producto agotado", "Lo sentimos, " + peliculaActual.titulo + " no tiene stock ahora mismo.", false);
      return;
    }
    abrirModal(
      "Añadir al carrito",
      "¿Quieres añadir " + peliculaActual.titulo + " a tu carrito?",
      true,
      function () {
        abrirModal("¡Añadido!", peliculaActual.titulo + " se ha añadido al carrito.", false);
      }
    );
  });
}

// Botón "Favorito" -> cambia el corazón y guarda en localStorage
const botonFavorito = document.getElementById("btn-favorito");
if (botonFavorito) {
  function leerFavoritos() {
    try { return JSON.parse(localStorage.getItem("karda-favoritos")) || []; }
    catch (error) { return []; }
  }

  let esFavorito = leerFavoritos().includes(peliculaActual.id);

  function pintarFavorito() {
    botonFavorito.innerHTML = '<span aria-hidden="true">' + (esFavorito ? "♥" : "♡") + "</span> Favorito";
    botonFavorito.setAttribute("aria-label",
      (esFavorito ? "Quitar " : "Añadir ") + peliculaActual.titulo + (esFavorito ? " de favoritos" : " a favoritos"));
  }

  pintarFavorito();

  botonFavorito.addEventListener("click", function () {
    esFavorito = !esFavorito;
    let lista = leerFavoritos().filter(function (id) { return id !== peliculaActual.id; });
    if (esFavorito) { lista.push(peliculaActual.id); }
    try { localStorage.setItem("karda-favoritos", JSON.stringify(lista)); } catch (error) { /* sin almacenamiento */ }
    pintarFavorito();
  });
}
