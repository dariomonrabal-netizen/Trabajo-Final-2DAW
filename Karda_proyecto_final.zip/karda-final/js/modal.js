// ============================================================
// modal.js
// Ventanas modales: avisos y confirmaciones.
//   abrirModal(titulo, mensaje, conCancelar, alConfirmar)
// ============================================================

function cerrarModal() {
  const modal = document.querySelector(".modal");
  if (modal) {
    modal.remove();
  }
  document.removeEventListener("keydown", cerrarConEscape);
}

function cerrarConEscape(evento) {
  if (evento.key === "Escape") {
    cerrarModal();
  }
}

function abrirModal(titulo, mensaje, conCancelar, alConfirmar) {
  cerrarModal(); // por si ya había uno abierto

  // Fondo oscuro
  const fondo = document.createElement("div");
  fondo.className = "modal";

  // Caja blanca
  const caja = document.createElement("div");
  caja.className = "modal__caja";
  caja.setAttribute("role", "dialog");
  caja.setAttribute("aria-modal", "true");
  caja.setAttribute("aria-labelledby", "modal-titulo");

  const h2 = document.createElement("h2");
  h2.id = "modal-titulo";
  h2.textContent = titulo;

  const p = document.createElement("p");
  p.textContent = mensaje;

  const botones = document.createElement("div");
  botones.className = "grupo-botones";

  const botonAceptar = document.createElement("button");
  botonAceptar.type = "button";
  botonAceptar.className = "boton boton--primario";
  botonAceptar.textContent = "Aceptar";
  botonAceptar.addEventListener("click", function () {
    cerrarModal();
    if (alConfirmar) {
      alConfirmar();
    }
  });
  botones.appendChild(botonAceptar);

  if (conCancelar) {
    const botonCancelar = document.createElement("button");
    botonCancelar.type = "button";
    botonCancelar.className = "boton boton--secundario";
    botonCancelar.textContent = "Cancelar";
    botonCancelar.addEventListener("click", cerrarModal);
    botones.appendChild(botonCancelar);
  }

  caja.appendChild(h2);
  caja.appendChild(p);
  caja.appendChild(botones);
  fondo.appendChild(caja);
  document.body.appendChild(fondo);

  // Cerrar al pulsar fuera de la caja o con la tecla Escape
  fondo.addEventListener("click", function (evento) {
    if (evento.target === fondo) {
      cerrarModal();
    }
  });
  document.addEventListener("keydown", cerrarConEscape);

  botonAceptar.focus();
}
