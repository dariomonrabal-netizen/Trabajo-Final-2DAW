// ============================================================
// mockData.js
// Datos simulados que hacen de "base de datos" del Proyecto 1.
// Cada objeto es una película/edición física de Karda.
// ============================================================

const peliculas = [
  {
    id: 1,
    titulo: "Pulp Fiction",
    director: "Quentin Tarantino",
    ano: 1994,
    duracion: 154,
    formato: "dvd",
    genero: "crimen",
    estado: "Como nuevo",
    precio: 14.99,
    stock: 5,
    oferta: true,
    imagen: "img/pulp-fiction.jpg",
    sinopsis: "Las vidas de dos sicarios, un boxeador, la esposa de un gánster y dos atracadores se cruzan en cuatro historias de violencia y redención."
  },
  {
    id: 2,
    titulo: "Dune: Parte Dos",
    director: "Denis Villeneuve",
    ano: 2024,
    duracion: 166,
    formato: "4k-uhd",
    genero: "ciencia-ficcion",
    estado: "Nuevo",
    precio: 24.99,
    stock: 3,
    oferta: false,
    imagen: "img/dune-parte-dos.jpg",
    sinopsis: "Paul Atreides se une a los Fremen para vengar la caída de su familia y evitar un futuro terrible que solo él puede ver."
  },
  {
    id: 3,
    titulo: "El Padrino",
    director: "Francis Ford Coppola",
    ano: 1972,
    duracion: 175,
    formato: "bluray",
    genero: "crimen",
    estado: "Muy bueno",
    precio: 29.99,
    stock: 2,
    oferta: false,
    imagen: "img/el-padrino.jpg",
    sinopsis: "La saga de la familia Corleone, una poderosa dinastía de la mafia, y el traspaso del poder de padre a hijo."
  },
  {
    id: 4,
    titulo: "Interstellar",
    director: "Christopher Nolan",
    ano: 2014,
    duracion: 169,
    formato: "bluray",
    genero: "ciencia-ficcion",
    estado: "Muy bueno",
    precio: 19.99,
    stock: 4,
    oferta: false,
    imagen: "img/interstellar.jpg",
    sinopsis: "Un grupo de exploradores viaja a través de un agujero de gusano para intentar garantizar la supervivencia de la humanidad en un futuro incierto."
  },
  {
    id: 5,
    titulo: "Blade Runner 2049",
    director: "Denis Villeneuve",
    ano: 2017,
    duracion: 164,
    formato: "4k-uhd",
    genero: "ciencia-ficcion",
    estado: "Como nuevo",
    precio: 22.99,
    stock: 1,
    oferta: false,
    imagen: "img/blade-runner-2049.jpg",
    sinopsis: "Un nuevo blade runner descubre un secreto enterrado que podría sumir en el caos a lo que queda de la sociedad."
  },
  {
    id: 6,
    titulo: "El Padrino II",
    director: "Francis Ford Coppola",
    ano: 1974,
    duracion: 202,
    formato: "bluray",
    genero: "crimen",
    estado: "Aceptable",
    precio: 18.99,
    stock: 2,
    oferta: false,
    imagen: "img/el-padrino-2.jpg",
    sinopsis: "Michael Corleone consolida su poder mientras se cuenta la juventud de Vito Corleone en Nueva York."
  },
  {
    id: 7,
    titulo: "Parásitos",
    director: "Bong Joon-ho",
    ano: 2019,
    duracion: 132,
    formato: "bluray",
    genero: "drama",
    estado: "Nuevo",
    precio: 17.99,
    stock: 6,
    oferta: false,
    imagen: "img/parasitos.jpg",
    sinopsis: "Una familia sin recursos se infiltra poco a poco en la vida de una familia adinerada, con consecuencias inesperadas."
  },
  {
    id: 8,
    titulo: "Matrix",
    director: "Lana y Lilly Wachowski",
    ano: 1999,
    duracion: 136,
    formato: "dvd",
    genero: "accion",
    estado: "Muy bueno",
    precio: 13.99,
    stock: 0,
    oferta: false,
    imagen: "img/matrix.jpg",
    sinopsis: "Un programador descubre que la realidad es una simulación y se une a la rebelión contra las máquinas."
  }
];

// Textos y clases CSS de cada formato (los usan las tarjetas y el detalle)
const NOMBRE_FORMATO = { "dvd": "DVD", "bluray": "Blu-ray", "4k-uhd": "4K UHD" };
const CLASE_FORMATO = { "dvd": "etiqueta--dvd", "bluray": "etiqueta--bluray", "4k-uhd": "etiqueta--4k" };
