// ============================================================
// favoritos.js
// Lee los ids guardados en localStorage y pinta las tarjetas
// de favoritos.html. Si no hay ninguno, deja el aviso de lista vacía.
// ============================================================

const zonaFavoritos = document.getElementById("lista-favoritos");
const avisoVacio = document.getElementById("favoritos-vacios");

if (zonaFavoritos) {
  let ids = [];
  try { ids = JSON.parse(localStorage.getItem("karda-favoritos")) || []; }
  catch (error) { ids = []; }

  const guardadas = peliculas.filter(function (p) { return ids.includes(p.id); });

  function pintarFavoritos() {
    zonaFavoritos.innerHTML = "";
    guardadas.forEach(function (pelicula) {
      const tarjeta = document.createElement("article");
      tarjeta.className = "tarjeta";
      tarjeta.innerHTML =
        '<a class="tarjeta__enlace" href="detalle.html?id=' + pelicula.id + '" aria-label="Ver detalle de ' + pelicula.titulo + '">' +
          '<figure class="tarjeta__portada"><img src="' + pelicula.imagen + '" alt="Portada de ' + pelicula.titulo + '" loading="lazy"></figure>' +
          '<h3 class="tarjeta__titulo">' + pelicula.titulo + "</h3>" +
        "</a>" +
        '<p class="texto-secundario">' + pelicula.director + "</p>" +
        '<p class="tarjeta__precio">' + pelicula.precio.toFixed(2).replace(".", ",") + " €</p>";

      const quitar = document.createElement("button");
      quitar.type = "button";
      quitar.className = "boton boton--secundario";
      quitar.textContent = "Quitar de favoritos";
      quitar.addEventListener("click", function () {
        const resto = ids.filter(function (id) { return id !== pelicula.id; });
        ids = resto;
        guardadas.splice(guardadas.indexOf(pelicula), 1);
        try { localStorage.setItem("karda-favoritos", JSON.stringify(resto)); } catch (error) { /* nada */ }
        pintarFavoritos();
      });
      tarjeta.appendChild(quitar);
      zonaFavoritos.appendChild(tarjeta);
    });
    avisoVacio.hidden = guardadas.length !== 0;
  }

  pintarFavoritos();
}
