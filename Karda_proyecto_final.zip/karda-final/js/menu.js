// ============================================================
// menu.js
// Menú hamburguesa para móvil y tablet.
// ============================================================

const botonMenu = document.querySelector(".menu-toggle");
const menuPrincipal = document.getElementById("menu-principal");

if (botonMenu && menuPrincipal) {
  botonMenu.addEventListener("click", function () {
    // classList.toggle devuelve true si la clase se ha añadido
    const abierto = menuPrincipal.classList.toggle("abierto");

    botonMenu.setAttribute("aria-expanded", abierto);
    botonMenu.setAttribute("aria-label", abierto ? "Cerrar menú" : "Abrir menú");
    botonMenu.textContent = abierto ? "✕" : "☰";
  });
}
