// ============================================================
// catalogo.js
// Pinta las tarjetas del Dashboard a partir de mockData.js y
// las filtra en tiempo real. Sirve para index.html (solo buscador)
// y para buscar.html (buscador + género + formato + orden).
// ============================================================

const listaPeliculas = document.getElementById("lista-peliculas");

if (listaPeliculas) {
  const buscador = document.getElementById("buscador");
  const filtroGenero = document.getElementById("filtro-genero");
  const filtroFormato = document.getElementById("filtro-formato");
  const filtroOrden = document.getElementById("orden");
  const formFiltros = document.getElementById("form-filtros");
  const contador = document.getElementById("contador");
  const sinResultados = document.getElementById("sin-resultados");

  // "14.99" -> "14,99 €"
  function formatearPrecio(numero) {
    return numero.toFixed(2).replace(".", ",") + " €";
  }

  // Quita tildes y pasa a minúsculas para comparar ("Parásitos" = "parasitos")
  function normalizar(texto) {
    return texto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }

  // Crea el <article> de una película con createElement + innerHTML
  function crearTarjeta(pelicula) {
    const tarjeta = document.createElement("article");
    tarjeta.className = "tarjeta";

    let etiquetas = '<span class="etiqueta ' + CLASE_FORMATO[pelicula.formato] + '">' +
      NOMBRE_FORMATO[pelicula.formato] + "</span>";
    if (pelicula.oferta) {
      etiquetas += '<span class="etiqueta etiqueta--oferta">OFERTA</span>';
    }
    if (pelicula.stock === 0) {
      etiquetas += '<span class="etiqueta etiqueta--agotado">AGOTADO</span>';
    }

    tarjeta.innerHTML =
      '<a class="tarjeta__enlace" href="detalle.html?id=' + pelicula.id + '" aria-label="Ver detalle de ' + pelicula.titulo + '">' +
        '<figure class="tarjeta__portada"><img src="' + pelicula.imagen + '" alt="Portada de ' + pelicula.titulo + '" loading="lazy"></figure>' +
        '<div class="tarjeta__etiquetas">' + etiquetas + "</div>" +
        '<h3 class="tarjeta__titulo">' + pelicula.titulo + "</h3>" +
      "</a>" +
      '<p class="texto-secundario">' + pelicula.director + "</p>" +
      '<p class="tarjeta__precio">' + formatearPrecio(pelicula.precio) + "</p>";

    return tarjeta;
  }

  // Vacía el contenedor y mete una tarjeta por cada película de la lista
  function pintarTarjetas(lista) {
    listaPeliculas.innerHTML = "";
    lista.forEach(function (pelicula) {
      listaPeliculas.appendChild(crearTarjeta(pelicula));
    });

    if (contador) {
      contador.textContent = "Mostrando " + lista.length + " de " + peliculas.length + " películas";
    }
    if (sinResultados) {
      sinResultados.hidden = lista.length !== 0;
    }
  }

  // Aplica todos los filtros que existan en la página
  function filtrar() {
    const texto = buscador ? normalizar(buscador.value.trim()) : "";
    const genero = filtroGenero ? filtroGenero.value : "";
    const formato = filtroFormato ? filtroFormato.value : "";
    const orden = filtroOrden ? filtroOrden.value : "destacados";

    const resultado = peliculas.filter(function (pelicula) {
      const coincideTexto = normalizar(pelicula.titulo).includes(texto) ||
        normalizar(pelicula.director).includes(texto);
      const coincideGenero = genero === "" || pelicula.genero === genero;
      const coincideFormato = formato === "" || pelicula.formato === formato;
      return coincideTexto && coincideGenero && coincideFormato;
    });

    if (orden === "precio") {
      resultado.sort(function (a, b) { return a.precio - b.precio; });
    } else if (orden === "ano") {
      resultado.sort(function (a, b) { return b.ano - a.ano; });
    }

    pintarTarjetas(resultado);
  }

  // Eventos: filtrar mientras el usuario escribe o cambia un select
  if (buscador) { buscador.addEventListener("input", filtrar); }
  if (filtroGenero) { filtroGenero.addEventListener("change", filtrar); }
  if (filtroFormato) { filtroFormato.addEventListener("change", filtrar); }
  if (filtroOrden) { filtroOrden.addEventListener("change", filtrar); }
  if (formFiltros) {
    formFiltros.addEventListener("submit", function (evento) {
      evento.preventDefault(); // no recargar la página
      filtrar();
    });
  }

  // Si llegamos desde Categorías (buscar.html?genero=accion) lo preseleccionamos
  const parametros = new URLSearchParams(window.location.search);
  if (filtroGenero && parametros.get("genero")) {
    filtroGenero.value = parametros.get("genero");
  }

  filtrar(); // primer pintado
}
