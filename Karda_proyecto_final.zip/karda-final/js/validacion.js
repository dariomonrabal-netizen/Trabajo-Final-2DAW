// ============================================================
// validacion.js
// Validación de formularios con JavaScript (sin tooltips del navegador).
// Se valida al salir del campo (blur), mientras se escribe (input)
// y al enviar el formulario (submit).
// ============================================================

// ---------- Funciones de ayuda ----------

function esEmailValido(texto) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(texto);
}

// Reglas por campo: cada función devuelve un mensaje de error
// o "" (cadena vacía) si el campo está bien.
const reglas = {
  // ----- Texto -----
  "nombre": function (campo) {
    const valor = campo.value.trim();
    if (valor === "") return "El nombre es obligatorio.";
    if (valor.length < 3) return "El nombre debe tener al menos 3 caracteres.";
    if (!/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ\s'-]+$/.test(valor)) return "El nombre solo puede contener letras.";
    return "";
  },
  "titulo": function (campo) {
    const valor = campo.value.trim();
    if (valor === "") return "El título es obligatorio.";
    if (valor.length > 100) return "El título no puede superar los 100 caracteres.";
    return "";
  },
  "director": function (campo) {
    const valor = campo.value.trim();
    if (valor === "") return "El director es obligatorio.";
    if (valor.length < 3) return "El director debe tener al menos 3 caracteres.";
    return "";
  },
  "sinopsis": function (campo) {
    const valor = campo.value.trim();
    if (valor === "") return "La sinopsis es obligatoria.";
    if (valor.length < 20) return "La sinopsis debe tener al menos 20 caracteres (llevas " + valor.length + ").";
    if (valor.length > 500) return "La sinopsis no puede superar los 500 caracteres.";
    return "";
  },
  "comentario": function (campo) {
    const valor = campo.value.trim();
    if (valor === "") return "Escribe un comentario.";
    if (valor.length < 10) return "El comentario debe tener al menos 10 caracteres.";
    return "";
  },

  // ----- Emails -----
  "correo": function (campo) {
    const valor = campo.value.trim();
    if (valor === "") return "El correo electrónico es obligatorio.";
    if (!esEmailValido(valor)) return "Introduce un correo válido, por ejemplo tu@correo.com.";
    return "";
  },
  "correo-newsletter": function (campo) {
    const valor = campo.value.trim();
    if (valor === "") return "Escribe tu correo para suscribirte.";
    if (!esEmailValido(valor)) return "Introduce un correo válido, por ejemplo tu@correo.com.";
    return "";
  },

  // ----- Contraseñas -----
  "contrasena": function (campo, formulario) {
    const valor = campo.value;
    if (valor === "") return "La contraseña es obligatoria.";
    if (valor.length < 8) return "La contraseña debe tener al menos 8 caracteres.";
    // En el login solo comprobamos la longitud; en el registro, algo más
    if (formulario.id === "form-registro") {
      if (!/[A-Za-z]/.test(valor)) return "La contraseña debe incluir al menos una letra.";
      if (!/[0-9]/.test(valor)) return "La contraseña debe incluir al menos un número.";
    }
    return "";
  },
  "repetir-contrasena": function (campo, formulario) {
    if (campo.value === "") return "Repite la contraseña.";
    if (campo.value !== formulario.querySelector("#contrasena").value) return "Las contraseñas no coinciden.";
    return "";
  },

  // ----- Fechas -----
  "fecha-nacimiento": function (campo) {
    if (campo.value === "") return "Introduce tu fecha de nacimiento.";
    const nacimiento = new Date(campo.value);
    const hoy = new Date();
    if (nacimiento > hoy) return "La fecha de nacimiento no puede ser futura.";
    if (nacimiento.getFullYear() < 1900) return "Introduce una fecha de nacimiento válida.";

    let edad = hoy.getFullYear() - nacimiento.getFullYear();
    const meses = hoy.getMonth() - nacimiento.getMonth();
    if (meses < 0 || (meses === 0 && hoy.getDate() < nacimiento.getDate())) {
      edad--;
    }
    if (edad < 18) return "Debes ser mayor de 18 años para crear una cuenta.";
    return "";
  },

  // ----- Números -----
  "ano": function (campo) {
    if (campo.value === "") return "El año es obligatorio.";
    const ano = Number(campo.value);
    const maximo = new Date().getFullYear() + 1;
    if (!Number.isInteger(ano) || ano < 1888 || ano > maximo) {
      return "Introduce un año entre 1888 y " + maximo + ".";
    }
    return "";
  },
  "precio": function (campo) {
    if (campo.value === "") return "El precio es obligatorio.";
    const precio = Number(campo.value);
    if (precio <= 0) return "El precio debe ser mayor que 0.";
    if (precio > 9999) return "El precio no puede superar los 9999 €.";
    return "";
  },
  "stock": function (campo) {
    if (campo.value === "") return "El stock es obligatorio.";
    const stock = Number(campo.value);
    if (!Number.isInteger(stock) || stock < 1) return "El stock debe ser un número entero de 1 o más.";
    return "";
  },

  // ----- Selects, checkbox y archivo -----
  "formato": function (campo) {
    return campo.value === "" ? "Selecciona un formato." : "";
  },
  "genero": function (campo) {
    return campo.value === "" ? "Selecciona un género." : "";
  },
  "estado": function (campo) {
    return campo.value === "" ? "Selecciona el estado de la edición." : "";
  },
  "valoracion": function (campo) {
    return campo.value === "" ? "Elige una valoración." : "";
  },
  "acepto-condiciones": function (campo) {
    return campo.checked ? "" : "Debes aceptar las condiciones de uso.";
  },
  "portada": function (campo) {
    if (campo.files.length === 0) return "Selecciona una imagen de portada.";
    if (!campo.files[0].type.startsWith("image/")) return "El archivo debe ser una imagen.";
    return "";
  }
};

// ---------- Mostrar / quitar errores en el DOM ----------

function mostrarError(campo, mensaje) {
  const contenedor = campo.parentElement;
  let aviso = contenedor.querySelector(".campo__error");

  if (!aviso) {
    aviso = document.createElement("span");
    aviso.className = "campo__error";
    aviso.id = "error-" + campo.id;
    aviso.setAttribute("aria-live", "polite");
    contenedor.appendChild(aviso);
  }

  aviso.textContent = mensaje;
  campo.classList.add("input-error");
  campo.classList.remove("input-ok");
  campo.setAttribute("aria-invalid", "true");
  campo.setAttribute("aria-describedby", aviso.id);
}

function quitarError(campo) {
  const aviso = campo.parentElement.querySelector(".campo__error");
  if (aviso) {
    aviso.remove();
  }
  campo.classList.remove("input-error");
  campo.classList.add("input-ok");
  campo.removeAttribute("aria-invalid");
  campo.removeAttribute("aria-describedby");
}

// Devuelve true si el campo es válido
function validarCampo(campo, formulario) {
  const regla = reglas[campo.id];
  if (!regla) {
    return true; // campo sin regla
  }
  const mensaje = regla(campo, formulario);
  if (mensaje === "") {
    quitarError(campo);
    return true;
  }
  mostrarError(campo, mensaje);
  return false;
}

// Deja el formulario como nuevo (sin errores ni colores)
function limpiarErrores(formulario) {
  formulario.querySelectorAll(".campo__error").forEach(function (aviso) { aviso.remove(); });
  formulario.querySelectorAll("input, select, textarea").forEach(function (campo) {
    campo.classList.remove("input-error", "input-ok");
    campo.removeAttribute("aria-invalid");
    campo.removeAttribute("aria-describedby");
    delete campo.dataset.tocado;
  });
}

// ---------- Qué pasa cuando el formulario es correcto ----------

function alEnviarCorrecto(formulario) {
  if (formulario.id === "form-login") {
    abrirModal("Sesión iniciada", "Has iniciado sesión correctamente (simulado).", false, function () {
      formulario.reset();
      limpiarErrores(formulario);
    });
  } else if (formulario.id === "form-registro") {
    abrirModal("¡Cuenta creada!", "Tu cuenta se ha creado correctamente (simulado).", false, function () {
      formulario.reset();
      limpiarErrores(formulario);
    });
  } else if (formulario.id === "form-newsletter") {
    abrirModal("¡Suscrito!", "Te has suscrito a la carta de Karda.", false, function () {
      formulario.reset();
      limpiarErrores(formulario);
    });
  } else if (formulario.id === "form-crear") {
    abrirModal("Publicar película", "¿Seguro que quieres publicar esta edición en Karda?", true, function () {
      formulario.reset();
      limpiarErrores(formulario);
      abrirModal("¡Publicada!", "Tu edición se ha publicado correctamente (simulado).", false);
    });
  } else if (formulario.id === "form-resena") {
    anadirResena(formulario);
    formulario.reset();
    limpiarErrores(formulario);
    abrirModal("Reseña publicada", "Gracias por compartir tu opinión.", false);
  }
}

// Crea la reseña nueva y la pone la primera de la lista
function anadirResena(formulario) {
  const estrellas = Number(formulario.querySelector("#valoracion").value);
  const comentario = formulario.querySelector("#comentario").value.trim();

  const resena = document.createElement("article");
  resena.className = "resena";

  const nombre = document.createElement("h3");
  nombre.textContent = "Tú";

  const valoracion = document.createElement("p");
  valoracion.setAttribute("role", "img");
  valoracion.className = "resena__valoracion";
  valoracion.setAttribute("aria-label", estrellas + " de 5 estrellas");
  valoracion.textContent = "★".repeat(estrellas) + "☆".repeat(5 - estrellas) + " " + estrellas + " de 5";

  const texto = document.createElement("p");
  texto.textContent = comentario;

  resena.appendChild(nombre);
  resena.appendChild(valoracion);
  resena.appendChild(texto);

  const lista = document.querySelector(".resenas__lista");
  lista.insertBefore(resena, lista.firstChild);
}

// ---------- Activar la validación en todos los formularios ----------

document.querySelectorAll("form[data-validar]").forEach(function (formulario) {
  const campos = formulario.querySelectorAll("input, select, textarea");

  campos.forEach(function (campo) {
    if (!reglas[campo.id]) {
      return;
    }

    // Al salir del campo: se marca como "tocado" y se valida
    campo.addEventListener("blur", function () {
      campo.dataset.tocado = "1";
      validarCampo(campo, formulario);
    });

    // Mientras se escribe: solo si ya lo había tocado (para no molestar)
    campo.addEventListener("input", function () {
      if (campo.dataset.tocado) {
        validarCampo(campo, formulario);
      }
      // Si cambia la contraseña, revisamos otra vez "repetir contraseña"
      if (campo.id === "contrasena") {
        const repetir = formulario.querySelector("#repetir-contrasena");
        if (repetir && repetir.dataset.tocado) {
          validarCampo(repetir, formulario);
        }
      }
    });

    // Selects, checkbox, fecha y archivo: validar en cuanto cambian
    campo.addEventListener("change", function () {
      campo.dataset.tocado = "1";
      validarCampo(campo, formulario);
    });
  });

  // Al enviar: se validan todos los campos
  formulario.addEventListener("submit", function (evento) {
    evento.preventDefault();

    let primerError = null;
    campos.forEach(function (campo) {
      if (!reglas[campo.id]) {
        return;
      }
      campo.dataset.tocado = "1";
      const valido = validarCampo(campo, formulario);
      if (!valido && !primerError) {
        primerError = campo;
      }
    });

    if (primerError) {
      primerError.focus();
      return;
    }
    alEnviarCorrecto(formulario);
  });

  // Botón "Descartar" del formulario de publicar (pide confirmación)
  const botonDescartar = formulario.querySelector("#btn-descartar");
  if (botonDescartar) {
    botonDescartar.addEventListener("click", function () {
      abrirModal("Descartar cambios", "¿Seguro que quieres borrar todos los datos del formulario?", true, function () {
        formulario.reset();
        limpiarErrores(formulario);
      });
    });
  }
});
