# Tablero Kanban — Karda

Copia del tablero de GitHub Projects (columnas: Por hacer · En curso · Completado).

## Completado
- [x] Sesión 1 · Maquetación base HTML semántico de las 9 páginas
- [x] Sesión 1 · Sistema de diseño con variables CSS (colores, tipografías, espacios)
- [x] Sesión 2 · Layout responsive con Grid y Flexbox (mobile-first)
- [x] Sesión 2 · Menú hamburguesa (menu.js)
- [x] Sesión 3 · Datos simulados (mockData.js) y renderizado dinámico del catálogo
- [x] Sesión 3 · Buscador y filtros en tiempo real (catalogo.js)
- [x] Sesión 3 · Ficha de detalle por parámetro de URL (detalle.js)
- [x] Sesión 4 · Validación de formularios (validacion.js) y modales (modal.js)
- [x] Sesión 4 · Favoritos con localStorage (favoritos.js)
- [x] Sesión 5 · Validación W3C (HTML y CSS) y consola sin errores
- [x] Sesión 5 · Despliegue en GitHub Pages y memoria técnica
